﻿# Tarea 2  Análisis de Datos

## Ejecución

### Parte 1
python src/parte1.py

### Parte 2
python src/parte2.py

## Estructura
- src/: scripts de análisis (Parte 1, Parte 2, etc.)
- out/: resultados generados
