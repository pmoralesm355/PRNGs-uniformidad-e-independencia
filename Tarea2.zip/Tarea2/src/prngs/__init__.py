from .lcg import LCG
from .middle_square import MiddleSquare
from .mt19937 import MT19937
from .bbs import BlumBlumShub
from .randu import RANDU
